function p = predict(Theta1, Theta2, X)
%PREDICT Predict the label of an input given a trained neural network
%   p = PREDICT(Theta1, Theta2, X) outputs the predicted label of X given the
%   trained weights of a neural network (Theta1, Theta2)

% Useful values
m = size(X, 1);
num_labels = size(Theta2, 1);

% You need to return the following variables correctly 
p = zeros(size(X, 1), 1);

% ====================== YOUR CODE HERE ======================
% Instructions: Complete the following code to make predictions using
%               your learned neural network. You should set p to a 
%               vector containing labels between 1 to num_labels.
%
% Hint: The max function might come in useful. In particular, the max
%       function can also return the index of the max element, for more
%       information see 'help max'. If your examples are in rows, then, you
%       can use max(A, [], 2) to obtain the max for each row.
%
X=[ones(m,1) X];
G=sigmoid(Theta1 * X');
%for i=1:m,
%  B=G(:,i);
%  for j=1:size(Theta1,1),
%    B(j)=0;
%    if B(j)==max(B),
%     B(j)=1;
%     end
%   end
% D(:,i)=B;
% end 
D=G; 
D=[ones(1,m);D];
H=sigmoid(Theta2 * D);
for i=1:m,
  C=H(:,i);
  for j=1:num_labels,
    if C(j)==max(C),
     p(i)=j; 
     end
   end 
 end





% =========================================================================


end
